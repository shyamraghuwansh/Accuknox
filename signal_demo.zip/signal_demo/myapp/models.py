from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
import threading

# Model for Question 1 and 2
class MyModel(models.Model):
    name = models.CharField(max_length=100)

# LogEntry model for Question 3
class LogEntry(models.Model):
    message = models.CharField(max_length=255)

# Signal receiver function for Question 1 and 2
@receiver(post_save, sender=MyModel)
def my_signal_receiver(sender, instance, **kwargs):
    print(f"Signal receiver started...")
    print(f"Signal receiver thread ID: {threading.get_ident()}")
    LogEntry.objects.create(message="Signal receiver executed")  # Used in Question 3
    print("Signal receiver finished.")
