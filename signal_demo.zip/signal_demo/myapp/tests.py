from django.test import TestCase
from myapp.models import MyModel, LogEntry
from django.db import transaction
import threading

class SignalTests(TestCase):

    def test_signal_execution_sync_and_thread(self):
        # Question 1 and 2: Test signal execution and thread identity
        print(f"Main thread ID: {threading.get_ident()}")
        MyModel.objects.create(name="Test Instance")

    def test_signal_transaction(self):
        # Question 3: Test signal runs in the same transaction
        try:
            with transaction.atomic():
                print("Creating MyModel instance...")
                MyModel.objects.create(name="Test Instance")

                # Force an exception to cause a rollback
                raise Exception("Forcing a rollback")

        except Exception as e:
            print(f"Exception occurred: {e}")

        # Check if the log entry was saved despite the rollback
        log_entries = LogEntry.objects.all()
        print(f"Number of log entries: {log_entries.count()}")
